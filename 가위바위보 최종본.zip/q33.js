
var user_input;
var user_choice = "";
var result_ = "";
var result_output = "";
var com_img = "";
var user_img = "";

window.onload = function () {
    user_input = document.getElementById("inp_txt");
    result_ = document.getElementById("result_area");
    com_img = document.getElementById("com_img");
    user_img = document.getElementById("user_img");
}

function button_onclick() {

    result_.value = "";

    while (1) {
        user_choice = user_input.value;
        if (user_choice == "가위" || user_choice == "바위" || user_choice == "보") break;
        else {
            result_.value = "잘못된 입력입니다.";
            return;
        }
    } //유저 입력

    switch(user_choice) {
        case "가위" :
            user_img.innerHTML = "<img src='man.png'><br><br><img src='scissors.png'>";
            break;
        case "바위" :
            user_img.innerHTML = "<img src='man.png'><br><br><img src='rock.png'>";
            break;
        case "보" :
            user_img.innerHTML = "<img src='man.png'><br><br><img src='paper.png'>";
            
            break;
    } //유저 이미지 출력

    var random = Math.floor(Math.random() * 3) + 1;
    var ai_choice;
    switch (random) {
        case 1:
            ai_choice = "가위";
            com_img.innerHTML = "<img src='computer.png'><br><br><img src='scissors.png'>";
            break;
        case 2:
            ai_choice = "바위";
            com_img.innerHTML = "<img src='computer.png'><br><br><img src='rock.png'>";
            break;
        default:
            ai_choice = "보";
            com_img.innerHTML = "<img src='computer.png'><br><br><img src='paper.png'>";
    } //컴퓨터 선택 계산 및 이미지 출력

    if (user_choice == ai_choice) {
        result_.value = "컴퓨터 : " + ai_choice + " vs 유저 : " + user_choice + "\n무승부!";
    }
    else if ((user_choice == "가위" && ai_choice == "바위") || (user_choice == "바위" && ai_choice == "보") || (user_choice == "보" && ai_choice == "가위")) {
        result_.value = ("컴퓨터 : " + ai_choice + " vs 유저 : " + user_choice + "\n패배!");
    }
    else {
        result_.value = ("컴퓨터 : " + ai_choice + " vs 유저 : " + user_choice + "\n승리!");
    } //결과 textbox에 출력

}